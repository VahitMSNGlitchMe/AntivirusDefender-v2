Lutfen thetruth.themepack dosyasini silmeyin ve onu C:\ klasorune atin

Herhangibi klasore degil